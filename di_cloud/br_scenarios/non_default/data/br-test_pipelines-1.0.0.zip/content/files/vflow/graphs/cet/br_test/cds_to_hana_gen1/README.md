CDS Gen1.v1 to HANA
===========
#### Description
The following graph is replicating data out of a defined CDS View in initial load mode from a S/4 HANA 2020 source system (Connection S4H_2020)
into HANA database as target. The graph is also collecting Trace Statistics in a Python operator to gather runtime statistics.

#### Operator Configuration

1. ABAP CDS Reader
   Make sure you select a valid ABAP connection, in this case we use S4H_2020. This is a shell operator where the actual ABAP operator is 
   stored in the ABAP source and after selecting the operator via the browse dialog dynamically fetching the metadata once the operator is selected.
   
   Version: com.sap.abap.cds.reader.v1
   Transfer Mode: Initial Load
   Records per Roundtrip: 10000
   
2. ABAP Converter 
   Make sure you select a valid ABAP connection, in this case we use S4H_2020 as an example. This is a shell operator where the actual ABAP operator is 
   stored in the ABAP source and after selecting the operator via the browse dialog dynamically fetching the metadata once the operator is selected.
   
   Format: json
   
3. Generic ABAP Message Controller
   The Generic ABAP Message Controller is a generic custom Python operator through which you can control the output of your message including the data format (json, csv, records).
   Each of the formats is being handled via a dedicated output port, where in this graph only wiretap is being used as a target.
   
   - Output csv: Is providing the data in csv format and sends it to HANA as target.
   
4. HANA Client
   No additional configuration needed as  it is being handled via Run Configuration.
   

#### Run Configuration
There are several Substitution Parameters defined that you need to specify using the "Run As" option fo this pipeline. There is also an example run configuration available that you can check.

1. Run graph As
   Name of the Graph at Runtime

2. ABAP_CDS_NAME
   Select one out of the following CDS Views for replicating data available in the S/4 HANA source system (S4H_2020):
   - ZCDS_SNWD_SO 
   - ZCDS_SWND_SO_I
   
3. HANA_CONNECTION
   Specify the connection ID of your connected HANA DB where you want to store the data.

4. RUN_ID
   This RUN_ID acts as a unqiue session id which is being used at multiple places. Please select a unique RUN ID for your execution!
   In this graph it is being used as susbcription in the CDS Reader V1 for the initial load as well as as table name sending the data to HANA Client operator
   

