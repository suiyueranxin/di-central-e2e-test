from datetime import datetime
import time
import pandas as pd
import json
from math import ceil

record_counter = 0

msg_counter = 0
n_recs_total = 0
n_bytes_total = 0
last_time = time.time()
first_time = last_time


def parse_json_and_trace(data):
    global msg_counter, n_recs_total, last_time, n_bytes_total

    n_bytes = len(data)
    data = json.loads(data)

    cur_time = time.time()
    diff_time = cur_time - last_time
    last_time = cur_time

    msg_counter += 1

    n_recs = len(data["DATA"])
    n_recs_total += n_recs
    n_bytes_total += n_bytes
    thr_recs = n_recs / diff_time
    thr_bytes = n_bytes / diff_time

    stats = {}

    stats["cnt_msg"] = msg_counter

    stats["recs_msg"] = n_recs
    stats["recs_total"] = n_recs_total
    stats["recs_thrp"] = thr_recs

    stats["bytes_msg"] = n_bytes
    stats["bytes_total"] = n_bytes_total
    stats["bytes_thrp"] = thr_bytes

    stats["running_since_start"] = cur_time - first_time

    api.logger.info("STATS <<< %s >>>" % json.dumps(stats))
    return data
    
def replaceSpecificValues(metadata, records):
    for metaDataItem in metadata:
        metaDataField = metaDataItem["FIELD"]
        metadataColName = metaDataField["COLUMNNAME"]
        metadataAbapType = metaDataField["ABAPTYPE"]
        for recordItem in records:
            if (metadataAbapType == "DATS" or metadataAbapType == "DATN") and (recordItem[metadataColName] == "9999-99-99" or recordItem[metadataColName] == "0000-00-00"):
                recordItem[metadataColName] = ""
            elif metaDataField["ABAPTYPE"] == "DEC" and metaDataField["ABAPLEN"] == "000021" and metaDataField["OUTPUTLEN"] == "000027" and metaDataField["DECIMALS"] == "000007":
                recordItem[metadataColName] = recordItem[metadataColName].replace("T", " ")
            elif metadataAbapType == "INT1" and recordItem[metadataColName] > 127:
                recordItem[metadataColName] = 0
            elif metadataAbapType == "DEC":
                recordItem[metadataColName] = ('{'+':.{0}f'.format(int(metaDataField["DECIMALS"])) +'}').format(recordItem[metadataColName])
            


def on_json_input(data):
    global record_counter

    data = parse_json_and_trace(data)

    now = datetime.now()
    dt_string = now.strftime("%Y%m%d%H%M%S%f")
    ABAP_subscription = api.config.ABAP_subscription

    if not data["DATA"]:
        api.logger.info("reached termination condition (no/empty DATA input).. waiting for 2 seconds")
        time.sleep(2)
        api.logger.info("sending termination event")
        api.send("terminate", "terminate")
    else:
        records = data.get('DATA')
        metadata = data.get('METADATA')
        api.logger.info("-----------records is ------------")
        api.logger.info(records)
        api.logger.info("-----------metadata is ------------")
        api.logger.info(metadata)
        replaceSpecificValues(metadata, records)
        df_metadata = pd.DataFrame(metadata)
        df_metadata = df_metadata.append({"FIELD": {"COLUMNNAME": "ABAP_SUBSCRIPTION"}}, ignore_index=True)
        df_metadata = df_metadata.append({"FIELD": {"COLUMNNAME": "DI_TIMESTAMP"}}, ignore_index=True)
        df_metadata = df_metadata.append({"FIELD": {"COLUMNNAME": "DI_SEQNO"}}, ignore_index=True)
        

        df = pd.DataFrame(records)
        df['ABAP_SUBSCRIPTION'] = ABAP_subscription
        df['DI_TIMESTAMP'] = dt_string
        df['DI_SEQNO'] = 0
        
        
        for i, row in df.iterrows():
            record_counter += 1
            df.at[i, 'DI_SEQNO'] = record_counter

        n_batch = int(api.config.max_batch_size)
        if n_batch > 0:
            dfs = [ df.loc[n_batch*i:n_batch*(i+1)-1] for i in range(ceil(len(df)/n_batch)) ]
        else:
            dfs = [df]

        for df in dfs:
            if api.config.json:
                resp = {'METADATA': json.loads(df_metadata.to_json(orient='records')),
                        'DATA': json.loads(df.to_json(orient='records'))}
                api.send("json", str(json.dumps(resp)))
            if api.config.csv:
                csv_data = df.to_csv(index=False)
                api.send("csv", csv_data)
            if api.config.records:
                records_data = df.values.tolist()
                api.send("records", records_data)


api.set_port_callback("jsonInput", on_json_input)
